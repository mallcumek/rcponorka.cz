<?php

use Latte\Runtime as LR;

/** source: /data/web/virtuals/337245/virtual/www/domains/ponorkapardubice.cz/app/UI/Dashboard/create.latte */
final class Template_791d3d01b1 extends Latte\Runtime\Template
{
	public const Source = '/data/web/virtuals/337245/virtual/www/domains/ponorkapardubice.cz/app/UI/Dashboard/create.latte';

	public const Blocks = [
		['head' => 'blockHead', 'content' => 'blockContent'],
	];


	public function main(array $ʟ_args): void
	{
		extract($ʟ_args);
		unset($ʟ_args);

		if ($this->global->snippetDriver?->renderSnippets($this->blocks[self::LayerSnippet], $this->params)) {
			return;
		}

		$this->renderBlock('head', get_defined_vars()) /* line 1 */;
		echo "\n";
		$this->renderBlock('content', get_defined_vars()) /* line 5 */;
	}


	/** {block head} on line 1 */
	public function blockHead(array $ʟ_args): void
	{
		extract($this->params);
		extract($ʟ_args);
		unset($ʟ_args);

		echo '    <link href="';
		echo LR\Filters::escapeHtmlAttr(LR\Filters::safeUrl($basePath)) /* line 2 */;
		echo '/assets/css/ponorka.css" rel="stylesheet">
';
	}


	/** {block content} on line 5 */
	public function blockContent(array $ʟ_args): void
	{
		extract($this->params);
		extract($ʟ_args);
		unset($ʟ_args);

		echo '<main id="main" class="">
    <section id="gallery" class="">

        <div class="container py-5 ">
            <div class="section-header ">
                <p class="text-start pb-3"><a href="';
		echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link('Gallery:default')) /* line 11 */;
		echo '">← zpět do galerie</a></p>
                <div class="row justify-content-center">
                    <div class="col-lg-6 bg-light text-dark">


                        <h1 class="text-center pt-3">Přidat fotku do galerie</h1>

';
		$ʟ_tmp = $this->global->uiControl->getComponent('galleryForm');
		if ($ʟ_tmp instanceof Nette\Application\UI\Renderable) $ʟ_tmp->redrawControl(null, false);
		$ʟ_tmp->render() /* line 18 */;

		echo '
                        <div class="d-flex justify-content-center p-3 ">

                                <img id="image-preview"
                                     class="border border-dark"

                                     src="https://placehold.co/300x300?text=Můžete nahrát obrázek."
                                     height="300" alt="Image preview"/>
                        </div>

                        <br>
                        </a>

                    </div>
                </div>
            </div>
        </div>
    </section>
</main>

<script type="text/javascript">

    // Preview an image before it is uploaded
    document.getElementById(\'frm-galleryForm-image\').onchange = evt => {
        const [file] = evt.target.files;
        if (file) {
            document.getElementById(\'image-preview\').src = URL.createObjectURL(file);
        }
    };
</script>';
	}
}
