<?php

use Latte\Runtime as LR;

/** source: /data/web/virtuals/337245/virtual/www/domains/ponorkapardubice.cz/app/UI/Gallery/show.latte */
final class Template_4e8e480e47 extends Latte\Runtime\Template
{
	public const Source = '/data/web/virtuals/337245/virtual/www/domains/ponorkapardubice.cz/app/UI/Gallery/show.latte';

	public const Blocks = [
		['head' => 'blockHead', 'content' => 'blockContent', 'title' => 'blockTitle'],
	];


	public function main(array $ʟ_args): void
	{
		extract($ʟ_args);
		unset($ʟ_args);

		if ($this->global->snippetDriver?->renderSnippets($this->blocks[self::LayerSnippet], $this->params)) {
			return;
		}

		$this->renderBlock('head', get_defined_vars()) /* line 1 */;
		echo "\n";
		$this->renderBlock('content', get_defined_vars()) /* line 8 */;
	}


	public function prepare(): array
	{
		extract($this->params);

		if (!$this->getReferringTemplate() || $this->getReferenceType() === 'extends') {
			foreach (array_intersect_key(['flash' => '14'], $this->params) as $ʟ_v => $ʟ_l) {
				trigger_error("Variable \$$ʟ_v overwritten in foreach on line $ʟ_l");
			}
		}
		return get_defined_vars();
	}


	/** {block head} on line 1 */
	public function blockHead(array $ʟ_args): void
	{
		extract($this->params);
		extract($ʟ_args);
		unset($ʟ_args);

		echo '    <link href="';
		echo LR\Filters::escapeHtmlAttr(LR\Filters::safeUrl($basePath)) /* line 2 */;
		echo '/assets/css/ponorka.css" rel="stylesheet">
';
	}


	/** {block content} on line 8 */
	public function blockContent(array $ʟ_args): void
	{
		extract($this->params);
		extract($ʟ_args);
		unset($ʟ_args);

		echo '
    <section id="gallery" class="p-0 m-0 pt-3">

        <div class="container">

';
		foreach ($flashes as $flash) /* line 14 */ {
			echo '                <div';
			echo ($ʟ_tmp = array_filter(['alert', 'alert-' . $flash->type])) ? ' class="' . LR\Filters::escapeHtmlAttr(implode(" ", array_unique($ʟ_tmp))) . '"' : "" /* line 14 */;
			echo '>';
			echo LR\Filters::escapeHtmlText($flash->message) /* line 14 */;
			echo '</div>
';

		}

		echo "\n";
		if ($user->isLoggedIn()) /* line 16 */ {
			echo '            <p class="text-start pb-0 mb-0 fs-4"><a href="';
			echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link('Gallery:default')) /* line 17 */;
			echo '">← zpět do galerie</a>
                        - <a href="';
			echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link('Dashboard:edit', [$post->id])) /* line 18 */;
			echo '" class="link-danger">upravit/smazat</a>
';
		} else /* line 19 */ {
			echo '            <p class="text-start pb-0 mb-0 fs-4"><a href="javascript:history.back()">← zpět</a>
';
		}
		echo '                </p>
                <div class="row justify-content-center">
';
		$this->renderBlock('title', get_defined_vars()) /* line 24 */;
		echo '                    <div class="pb-3 text-center ">
                        <!-- Přepsání koncovky názvu obrázku z databáze na -1920wmax.webp, pro největší dochované rozlišení nahraného souboru s width max. 1920px -->
                        <img class="img-fluid border border-dark" loading="lazy"
                             src="';
		if ($post->image_path) /* line 28 */ {
			echo LR\Filters::escapeHtmlAttr(LR\Filters::safeUrl(($this->filters->replace)($post->image_path, '.webp', '-1920wmax.webp'))) /* line 28 */;
		} else /* line 28 */ {
			echo 'https://placehold.co/300x300?text=You can change the image';
		}
		echo '"

                             alt="';
		echo LR\Filters::escapeHtmlAttr($post->title) /* line 30 */;
		echo '"
                             class="border border-dark">
                        </a>

                    </div>
                </div>


        </div>

    </section>


';
	}


	/** n:block="title" on line 24 */
	public function blockTitle(array $ʟ_args): void
	{
		extract($this->params);
		extract($ʟ_args);
		unset($ʟ_args);

		echo '                    <h1 class="p-0 m-0 pb-2  text-center text-white  fw-bold fs-5 ">';
		echo LR\Filters::escapeHtmlText($post->title) /* line 24 */;
		echo '</h1>
';
	}
}
