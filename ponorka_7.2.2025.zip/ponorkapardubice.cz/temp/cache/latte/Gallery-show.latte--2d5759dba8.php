<?php

use Latte\Runtime as LR;

/** source: /data/web/virtuals/337245/virtual/www/domains/ponorkapardubice.cz/app/UI/Gallery/show.latte */
final class Template_2d5759dba8 extends Latte\Runtime\Template
{
	public const Source = '/data/web/virtuals/337245/virtual/www/domains/ponorkapardubice.cz/app/UI/Gallery/show.latte';

	public const Blocks = [
		['head' => 'blockHead', 'content' => 'blockContent', 'title' => 'blockTitle'],
	];


	public function main(array $ʟ_args): void
	{
		extract($ʟ_args);
		unset($ʟ_args);

		if ($this->global->snippetDriver?->renderSnippets($this->blocks[self::LayerSnippet], $this->params)) {
			return;
		}

		$this->renderBlock('head', get_defined_vars()) /* line 1 */;
		echo "\n";
		$this->renderBlock('content', get_defined_vars()) /* line 8 */;
	}


	/** {block head} on line 1 */
	public function blockHead(array $ʟ_args): void
	{
		extract($this->params);
		extract($ʟ_args);
		unset($ʟ_args);

		echo '    <link href="';
		echo LR\Filters::escapeHtmlAttr(LR\Filters::safeUrl($basePath)) /* line 2 */;
		echo '/assets/css/ponorka.css" rel="stylesheet">
';
	}


	/** {block content} on line 8 */
	public function blockContent(array $ʟ_args): void
	{
		extract($this->params);
		extract($ʟ_args);
		unset($ʟ_args);

		echo '<main id="main" class="">
    <section id="gallery" class="">

        <div class="container py-5 ">
            <div class="section-header ">
                <p class="text-start pb-3"><a href="';
		echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link('Gallery:default')) /* line 14 */;
		echo '">← zpět do galerie </a>
';
		if ($user->isLoggedIn()) /* line 15 */ {
			echo '                        - <a href="';
			echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link('Dashboard:edit', [$post->id])) /* line 16 */;
			echo '" class="link-danger">upravit</a>
';
		}
		echo '                </p>
                <div class="row justify-content-center">
';
		$this->renderBlock('title', get_defined_vars()) /* line 20 */;
		echo '                    <div class="pb-3 text-center ">
                        <!-- Přepsání koncovky názvu obrázku z databáze, pro zobrazení malého resize náhledu-->
                        <img class="border border-dark w-100" loading="lazy"
                             src="';
		if ($post->image_path) /* line 24 */ {
			echo LR\Filters::escapeHtmlAttr(LR\Filters::safeUrl(($this->filters->replace)($post->image_path, '.webp', '-1920wmax.webp'))) /* line 24 */;
		} else /* line 24 */ {
			echo 'https://placehold.co/300x300?text=You can change the image';
		}
		echo '"
                             width="300"
                             alt="';
		echo LR\Filters::escapeHtmlAttr($post->title) /* line 26 */;
		echo '"
                             class="border border-dark">
                        </a>

                    </div>
                </div>
            </div>
            <div class="wrapper">
            </div>
        </div>

    </section>
</main>

';
	}


	/** n:block="title" on line 20 */
	public function blockTitle(array $ʟ_args): void
	{
		extract($this->params);
		extract($ʟ_args);
		unset($ʟ_args);

		echo '                    <h1 class="p-0 m-0  text-center text-warning  fw-bold ">';
		echo LR\Filters::escapeHtmlText($post->title) /* line 20 */;
		echo '</h1>
';
	}
}
