-- phpMyAdmin SQL Dump
-- version 3.5.8.2
-- http://www.phpmyadmin.net
--
-- Počítač: md417.wedos.net:3306
-- Vygenerováno: Pát 07. úno 2025, 08:16
-- Verze serveru: 10.4.34-MariaDB-log
-- Verze PHP: 5.4.23

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Databáze: `d337245_ponorka`
--

-- --------------------------------------------------------

--
-- Struktura tabulky `gallery`
--

CREATE TABLE IF NOT EXISTS `gallery` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `title` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `title_slug` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `image` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `image_path` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci AUTO_INCREMENT=12 ;

--
-- Vypisuji data pro tabulku `gallery`
--

INSERT INTO `gallery` (`id`, `title`, `title_slug`, `image`, `image_path`) VALUES
(6, 'Sodoma Gomora v Ponorce', 'psukanec', 'sodomagomora.webp', '/gallery_data/6/sodomagomora.webp'),
(7, 'Pčoukan', 'pcoukan', 'whatsapp-image-2025-01-27-at-12.36.16.webp', '/gallery_data/7/whatsapp-image-2025-01-27-at-12.36.16.webp'),
(8, 'Druhá vlna v Ponorce ', 'pcoukan', 'druhavlna.webp', '/gallery_data/8/druhavlna.webp'),
(9, 'Moribundus Oblivion', 'moribundus-oblivion', 'gallery5.webp', '/gallery_data/9/gallery5.webp'),
(10, '', '', 'gallery4.webp', '/gallery_data/10/gallery4.webp'),
(11, 'Benjamins Clan v Ponorce 22.2.2025.', 'benjamins-clan-v-ponorce-22-2-2025', 'benjamingsclan.webp', '/gallery_data/11/benjamingsclan.webp');

-- --------------------------------------------------------

--
-- Struktura tabulky `posts`
--

CREATE TABLE IF NOT EXISTS `posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `title_slug` text NOT NULL,
  `image` text NOT NULL,
  `image_path` text NOT NULL,
  `content` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `opentime` text NOT NULL,
  `starttime` text NOT NULL,
  `presaleprice` text NOT NULL,
  `onsiteprice` text NOT NULL,
  `eventdate` date NOT NULL,
  `tickets` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci AUTO_INCREMENT=11 ;

--
-- Vypisuji data pro tabulku `posts`
--

INSERT INTO `posts` (`id`, `title`, `title_slug`, `image`, `image_path`, `content`, `created_at`, `opentime`, `starttime`, `presaleprice`, `onsiteprice`, `eventdate`, `tickets`) VALUES
(10, 'Druhá vlna', 'druha-vlna', 'druhavlna.webp', '/data/10/druhavlna.webp', 'Těšit se můžete na Unlucky eight, Musiclan, Lokaas, Sxdkid, Linx king, Uzix, Reno a přijde i Special guest.', '2025-02-03 09:23:32', '16:00', '19:30', '0', '250', '2025-02-07', '');

-- --------------------------------------------------------

--
-- Struktura tabulky `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `role` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci AUTO_INCREMENT=5 ;

--
-- Vypisuji data pro tabulku `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `role`) VALUES
(4, 'mallcom', '$2y$10$PLi0I2bAF6tX7pt0sqlVOOn88OsmSJm449QtQYtjAvPpw.NGZBmQO', 'martin.krsik@gmail.com', NULL);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
