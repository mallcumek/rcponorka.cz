<?php

use Latte\Runtime as LR;

/** source: /data/web/virtuals/337245/virtual/www/domains/ponorkapardubice.cz/app/UI/Edit/create.latte */
final class Template_d06eadb301 extends Latte\Runtime\Template
{
	public const Source = '/data/web/virtuals/337245/virtual/www/domains/ponorkapardubice.cz/app/UI/Edit/create.latte';

	public const Blocks = [
		['head' => 'blockHead', 'content' => 'blockContent'],
	];


	public function main(array $ʟ_args): void
	{
		extract($ʟ_args);
		unset($ʟ_args);

		if ($this->global->snippetDriver?->renderSnippets($this->blocks[self::LayerSnippet], $this->params)) {
			return;
		}

		$this->renderBlock('head', get_defined_vars()) /* line 1 */;
		$this->renderBlock('content', get_defined_vars()) /* line 4 */;
	}


	/** {block head} on line 1 */
	public function blockHead(array $ʟ_args): void
	{
		extract($this->params);
		extract($ʟ_args);
		unset($ʟ_args);

		echo '    <link href="';
		echo LR\Filters::escapeHtmlAttr(LR\Filters::safeUrl($basePath)) /* line 2 */;
		echo '/assets/css/ponorka.css" rel="stylesheet">
';
	}


	/** {block content} on line 4 */
	public function blockContent(array $ʟ_args): void
	{
		extract($this->params);
		extract($ʟ_args);
		unset($ʟ_args);

		echo '<main id="main" class="">
    <section id="gallery" class="">

        <div class="container py-5 ">
            <div class="section-header ">
                <p class="text-start pb-3"><a href="';
		echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link('Home:default#schedule')) /* line 10 */;
		echo '">← zpět na program</a>
                <div class="row justify-content-center">
                    <div class="col-lg-6 bg-light text-dark">


                        <h1 class="text-center pt-3">Vytvořit událost</h1>

';
		$ʟ_tmp = $this->global->uiControl->getComponent('postForm');
		if ($ʟ_tmp instanceof Nette\Application\UI\Renderable) $ʟ_tmp->redrawControl(null, false);
		$ʟ_tmp->render() /* line 17 */;

		echo '
                        <div class="d-flex justify-content-center p-3 ">

                            <img id="image-preview"
                                 class="border border-dark"

                                 src="https://placehold.co/300x300?text=Náhled obrázku"
                                 height="300" alt="Image preview" />

                        </div>


                    </div>
                </div>
            </div>
        </div>
    </section>
</main>

<script type="text/javascript">

    // Preview an image before it is uploaded
    document.getElementById(\'frm-postForm-image\').onchange = evt => {
        const [file] = evt.target.files;
        if (file) {
            document.getElementById(\'image-preview\').src = URL.createObjectURL(file);
        }
    };
</script>';
	}
}
