<?php

use Latte\Runtime as LR;

/** source: /data/web/virtuals/337245/virtual/www/domains/ponorkapardubice.cz/app/UI/Home/default.latte */
final class Template_4ab1854867 extends Latte\Runtime\Template
{
	public const Source = '/data/web/virtuals/337245/virtual/www/domains/ponorkapardubice.cz/app/UI/Home/default.latte';

	public const Blocks = [
		['content' => 'blockContent'],
	];


	public function main(array $ʟ_args): void
	{
		extract($ʟ_args);
		unset($ʟ_args);

		if ($this->global->snippetDriver?->renderSnippets($this->blocks[self::LayerSnippet], $this->params)) {
			return;
		}

		$this->renderBlock('content', get_defined_vars()) /* line 1 */;
	}


	public function prepare(): array
	{
		extract($this->params);

		if (!$this->getReferringTemplate() || $this->getReferenceType() === 'extends') {
			foreach (array_intersect_key(['post' => '42'], $this->params) as $ʟ_v => $ʟ_l) {
				trigger_error("Variable \$$ʟ_v overwritten in foreach on line $ʟ_l");
			}
		}
		return get_defined_vars();
	}


	/** {block content} on line 1 */
	public function blockContent(array $ʟ_args): void
	{
		extract($this->params);
		extract($ʟ_args);
		unset($ʟ_args);

		echo '    <!-- ======= Hero Section ======= -->
    <section id="hero">
        <div class="hero-container">
            <h1 class="mb-4 pb-0">Rock Club<br><span>Ponorka</span></h1>
            <!--
                        <div class="m-0 p-0 pb-2">
                            <a href="https://www.facebook.com/p/RC-Ponorka-100059010897346/">
                            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" fill="currentColor" class="bi bi-facebook" viewBox="0 0 16 16">
                                <path d="M16 8.049c0-4.446-3.582-8.05-8-8.05C3.58 0-.002 3.603-.002 8.05c0 4.017 2.926 7.347 6.75 7.951v-5.625h-2.03V8.05H6.75V6.275c0-2.017 1.195-3.131 3.022-3.131.876 0 1.791.157 1.791.157v1.98h-1.009c-.993 0-1.303.621-1.303 1.258v1.51h2.218l-.354 2.326H9.25V16c3.824-.604 6.75-3.934 6.75-7.951"/>
                            </svg></a>

                            <a class="ps-2" href="https://www.instagram.com/explore/locations/894605490/rc-ponorka/">
                                <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" fill="currentColor" class="bi bi-instagram" viewBox="0 0 16 16">
                                    <path d="M8 0C5.829 0 5.556.01 4.703.048 3.85.088 3.269.222 2.76.42a3.9 3.9 0 0 0-1.417.923A3.9 3.9 0 0 0 .42 2.76C.222 3.268.087 3.85.048 4.7.01 5.555 0 5.827 0 8.001c0 2.172.01 2.444.048 3.297.04.852.174 1.433.372 1.942.205.526.478.972.923 1.417.444.445.89.719 1.416.923.51.198 1.09.333 1.942.372C5.555 15.99 5.827 16 8 16s2.444-.01 3.298-.048c.851-.04 1.434-.174 1.943-.372a3.9 3.9 0 0 0 1.416-.923c.445-.445.718-.891.923-1.417.197-.509.332-1.09.372-1.942C15.99 10.445 16 10.173 16 8s-.01-2.445-.048-3.299c-.04-.851-.175-1.433-.372-1.941a3.9 3.9 0 0 0-.923-1.417A3.9 3.9 0 0 0 13.24.42c-.51-.198-1.092-.333-1.943-.372C10.443.01 10.172 0 7.998 0zm-.717 1.442h.718c2.136 0 2.389.007 3.232.046.78.035 1.204.166 1.486.275.373.145.64.319.92.599s.453.546.598.92c.11.281.24.705.275 1.485.039.843.047 1.096.047 3.231s-.008 2.389-.047 3.232c-.035.78-.166 1.203-.275 1.485a2.5 2.5 0 0 1-.599.919c-.28.28-.546.453-.92.598-.28.11-.704.24-1.485.276-.843.038-1.096.047-3.232.047s-2.39-.009-3.233-.047c-.78-.036-1.203-.166-1.485-.276a2.5 2.5 0 0 1-.92-.598 2.5 2.5 0 0 1-.6-.92c-.109-.281-.24-.705-.275-1.485-.038-.843-.046-1.096-.046-3.233s.008-2.388.046-3.231c.036-.78.166-1.204.276-1.486.145-.373.319-.64.599-.92s.546-.453.92-.598c.282-.11.705-.24 1.485-.276.738-.034 1.024-.044 2.515-.045zm4.988 1.328a.96.96 0 1 0 0 1.92.96.96 0 0 0 0-1.92m-4.27 1.122a4.109 4.109 0 1 0 0 8.217 4.109 4.109 0 0 0 0-8.217m0 1.441a2.667 2.667 0 1 1 0 5.334 2.667 2.667 0 0 1 0-5.334"/>
                                </svg></a>
                        </div>

             -->

            <a href="#schedule" class="about-btn scrollto">Program</a>
            <a href="#contact" class="about-btn scrollto">Kontakt</a>
            <p class="text-white pt-2">Ponorka otevřená od 16:00 do 22:00.</p>
        </div>
    </section><!-- End Hero Section -->

    <main id="main">
        <!-- ======= Schedule Section ======= -->
        <section id="schedule" class="section-with-bg">
            <div class="container">
                <div class="section-header">
                    <h2>Program</h2>
                    <p>Kalendář akcí v rockovém klubu Ponorka, Pardubice.</p>
';
		if ($user->isLoggedIn()) /* line 34 */ {
			echo '                        <h3><a href="';
			echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link('Edit:create')) /* line 35 */;
			echo '" class="link-danger fw-bold">Vytvořit novou událost</a></h3>
';
		}
		echo '                </div>
                <div class="tab-content row justify-content-center">
                    <div class="col-lg-9 tab-pane fade show active">
';
		foreach ($posts as $post) /* line 42 */ {
			echo '                        <div class="row schedule-item">
                            <div class="col-md-2 d-flex align-items-center">
                                <!-- Použití formátovaného data z pole -->
                                <time>';
			echo LR\Filters::escapeHtmlText($formattedDates[$post->id]) /* line 45 */;
			echo '</time>
                            </div>
                            <div class="col-md-10">
                                <div class="speaker bg-transparent">
                                    <a href="';
			echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link('Post:show', [$post->id])) /* line 49 */;
			echo '#schedule">
                                        <!-- Přepsání koncovky názvu obrázku z databáze, pro zobrazení malého resize náhledu -->
                                        <img loading="lazy"
                                             src="';
			if ($post->image_path) /* line 52 */ {
				echo LR\Filters::escapeHtmlAttr(LR\Filters::safeUrl(($this->filters->replace)($post->image_path, '.webp', '-400w.webp'))) /* line 52 */;
			} else /* line 52 */ {
				echo 'https://placehold.co/300x300?text=You can change the image';
			}
			echo '"
                                             alt="';
			echo LR\Filters::escapeHtmlAttr($post->title) /* line 53 */;
			echo '"
                                             class="pt-1">
                                    </a>
                                </div>
                                <div class="text ">
                                    <h3 class="fs-4"><a href="';
			echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link('Post:show', [$post->id])) /* line 58 */;
			echo '#schedule">';
			echo LR\Filters::escapeHtmlText($post->title) /* line 58 */;
			echo '</a>
                                    </h3>
                                    <p>Začátek: <strong>';
			echo LR\Filters::escapeHtmlText($post->starttime) /* line 60 */;
			echo '</strong> <br>

';
			if ($post->endtime) /* line 62 */ {
				echo '                                        Konec:
                                        <strong>';
				echo LR\Filters::escapeHtmlText($post->endtime) /* line 64 */;
				echo '</strong>
';
			}
			echo '
                                    </p>

';
			if ($post->onsiteprice) /* line 69 */ {
				echo '                                        <p>Na místě: <strong>';
				echo LR\Filters::escapeHtmlText($post->onsiteprice) /* line 70 */;
				echo ' Kč</strong>
                                        </p>
';
			}
			if ($post->presaleprice) /* line 73 */ {
				echo '                                        <p>Předprodej: <strong>';
				echo LR\Filters::escapeHtmlText($post->presaleprice) /* line 74 */;
				echo ' Kč</strong> <br>
                                            <a href="';
				echo LR\Filters::escapeHtmlAttr(LR\Filters::safeUrl($post->tickets)) /* line 75 */;
				echo '">
                                                <button type="button" class="btn btn-sm btn-warning">Vstupenky</button>
                                            </a>
                                        </p>
';
			}
			echo '                                </div>
                                <p class="text-dark-udalost pt-1">';
			echo LR\Filters::escapeHtmlText(($this->filters->truncate)($post->content, 256)) /* line 81 */;
			echo '</p>
                            </div>
                            <p>';
			if ($user->isLoggedIn()) /* line 83 */ {
				echo '
                                    - <a href="';
				echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link('Edit:edit', [$post->id])) /* line 84 */;
				echo '" class="link-danger">upravit</a>
';
			}
			echo '                                </p>
                        </div>
';

		}

		echo '
                    </div> <!-- End Schdule Day 1 col -->

                </div> <!-- End tab-content row-->

            </div>

        </section><!-- End Schedule Section -->


        <!-- ======= Contact Section ======= -->
        <section id="contact" class="section-bg">

            <div class="container">

                <div class="section-header">
                    <h2>Kontakt</h2>
                    <p class="text-dark">Máte-li dotaz, pište, volejte, těšíme se na vás.
                    </p>
                </div>
           <p class="text-center">     <span class="text-uppercase">Ponorka otevřená od 16:00 do 22:00.</span></p>
                <div class="row contact-info">

                    <div class="col-md-4 col-6">
                        <div class="contact-address">
                            <i class="bi bi-geo-alt"></i>
                            <h3>Club Ponorka</h3>
                            <address class="text-dark">Jiráskova 29, 530 02 Pardubice I</address>
                        </div>
                    </div>

                    <div class="col-md-4 col-6">
                        <div class="contact-phone">
                            <a href="tel:+420603260359" class="text-dark"><i class="bi bi-phone"></i></a>
                                <a href="tel:+420603260359" class="text-dark"> <h3>Telefon</h3></a>
                            <p><a href="tel:+420603260359" class="text-dark">+420 603 260 359</a></p>
                        </div>
                    </div>

                    <div class="col-md-4 col-6">
                        <div class="contact-email">
                            <a href="mailto:falcon.prod@seznam.cz"><i class="bi bi-envelope"></i></a>
                            <a href="mailto:falcon.prod@seznam.cz"><h3>Email</h3></a>
                            <p><a href="mailto:falcon.prod@seznam.cz">falcon.prod@seznam.cz</a></p>
                        </div>
                    </div>
                    <div class="col-md-4 col-6">
                        <div class="contact-email">
                           <a href="https://www.facebook.com/p/RC-Ponorka-100059010897346/"> <i class="bi bi-facebook"></i></a>
                            <a href="https://www.facebook.com/p/RC-Ponorka-100059010897346/">  <h3>Facebook</h3></a>

                        </div>
                    </div>
                    <div class="col-md-4 col-6">
                        <div class="contact-email">
                            <a href="https://www.instagram.com/explore/locations/894605490/rc-ponorka/">   <i class="bi bi-instagram"></i></a>
                            <a href="https://www.instagram.com/explore/locations/894605490/rc-ponorka/">  <h3>Instagram</h3></a>

                        </div>
                    </div>

                </div>

                <div class="row gy-4 mt-1">
                    <div class="col-lg-6" data-aos="fade-up" data-aos-delay="300">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2562.690654911395!2d15.7820078!3d50.0358921!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x470dcc8d5f622377%3A0xb527a79d428fe4d6!2sClub%20Ponorka!5e0!3m2!1scs!2scz!4v1739105875283!5m2!1scs!2scz"
                                frameborder="0" style="border:0; width: 100%; height: 400px;" allowfullscreen=""
                                loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </div><!-- End Google Maps -->
                    <div class="col-lg-6">
                        <h3>Napište nám zprávu</h3>
                        <div class="form">
                            <form action="#name" method="post" role="form" class="php-email-form">
                                <div class="row">
                                    <div class="form-group col-md-6">
                                        <input type="text" name="name" class="form-control" id="name"
                                               placeholder="Jméno"
                                               required>
                                    </div>
                                    <div class="form-group col-md-6 mt-3 mt-md-0">
                                        <input type="email" class="form-control" name="email" id="email"
                                               placeholder="Email"
                                               required>
                                    </div>
                                </div>
                                <div class="form-group mt-3">
                                    <input type="text" class="form-control" name="subject" id="subject"
                                           placeholder="Předmět"
                                           required>
                                </div>
                                <div class="form-group mt-3">
                            <textarea class="form-control" name="message" rows="5" placeholder="Zpráva"
                                      required></textarea>
                                </div>
                                <div class="my-3">
                                    <div class="loading">Loading</div>
                                    <div class="error-message"></div>
                                    <div class="sent-message">Your message has been sent. Thank you!</div>
                                </div>
                                <div class="text-center">
                                    <button type="submit" class="text-dark">Odeslat zprávu</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

            </div>


            </div>
        </section><!-- End Contact Section -->

    </main><!-- End #main -->


';
	}
}
