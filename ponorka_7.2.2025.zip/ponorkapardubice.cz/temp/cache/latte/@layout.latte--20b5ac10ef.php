<?php

use Latte\Runtime as LR;

/** source: /data/web/virtuals/337245/virtual/www/domains/ponorkapardubice.cz/app/UI/@layout.latte */
final class Template_20b5ac10ef extends Latte\Runtime\Template
{
	public const Source = '/data/web/virtuals/337245/virtual/www/domains/ponorkapardubice.cz/app/UI/@layout.latte';

	public const Blocks = [
		['head' => 'blockHead', 'scripts' => 'blockScripts'],
	];


	public function main(array $ʟ_args): void
	{
		extract($ʟ_args);
		unset($ʟ_args);

		if ($this->global->snippetDriver?->renderSnippets($this->blocks[self::LayerSnippet], $this->params)) {
			return;
		}

		echo '
<!DOCTYPE html>
<html lang="cs">
<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta name="robots" content="noindex, nofollow">
    <title>';
		if ($this->hasBlock('title')) /* line 9 */ {
			$this->renderBlock('title', [], function ($s, $type) {
				$ʟ_fi = new LR\FilterInfo($type);
				return LR\Filters::convertTo($ʟ_fi, 'html', $this->filters->filterContent('stripHtml', $ʟ_fi, $s));
			}) /* line 9 */;
			echo ' | ';
		}
		echo 'RC Ponorka Pardubice</title>
    <meta content="Rockový klub, bar, hospoda - Ponorka Pardubice." name="description">
    <meta content="rock, club, ponorka, pub" name="keywords">
    <!-- Favicons -->
    <link href="';
		echo LR\Filters::escapeHtmlAttr(LR\Filters::safeUrl($basePath)) /* line 13 */;
		echo '/assets/img/favicon.png" rel="icon">
    <link href="';
		echo LR\Filters::escapeHtmlAttr(LR\Filters::safeUrl($basePath)) /* line 14 */;
		echo '/assets/img/apple-touch-icon.png" rel="apple-touch-icon">
    <!-- Vendor CSS Files -->
    <link href="';
		echo LR\Filters::escapeHtmlAttr(LR\Filters::safeUrl($basePath)) /* line 16 */;
		echo '/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!--  pro PHPStorm nápovědu,  bez CDN prostě nenapovídá styly -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="';
		echo LR\Filters::escapeHtmlAttr(LR\Filters::safeUrl($basePath)) /* line 19 */;
		echo '/assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <!-- Template Main CSS File -->
    <link href="';
		echo LR\Filters::escapeHtmlAttr(LR\Filters::safeUrl($basePath)) /* line 21 */;
		echo '/assets/css/style.css" rel="stylesheet">
';
		$this->renderBlock('head', get_defined_vars()) /* line 22 */;
		echo '


</head>
<body>
<!-- ======= Header ======= -->
<header id="header" class="d-flex align-items-center ">
    <div class="container-fluid container-xxl d-flex align-items-center ">
        <div id="logo" class="me-auto">
            <!-- Uncomment below if you prefer to use a text logo -->
            <!-- <h1><a href="index.html">The<span>Event</span></a></h1>-->
            <a href="';
		echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link('Home:default')) /* line 37 */;
		echo '" class="scrollto"><img src="';
		echo LR\Filters::escapeHtmlAttr(LR\Filters::safeUrl($basePath)) /* line 37 */;
		echo '/assets/img/rcklubponorka.webp" height="200" alt="" title=""></a>
        </div>
        <nav id="navbar" class="navbar order-last order-lg-0">
            <ul>
                <li><a class="nav-link scrollto" href="';
		echo LR\Filters::escapeHtmlAttr(LR\Filters::safeUrl($basePath)) /* line 41 */;
		echo '/#hero">Domů</a></li>
                <li><a class="nav-link scrollto" href="';
		echo LR\Filters::escapeHtmlAttr(LR\Filters::safeUrl($basePath)) /* line 42 */;
		echo '/#schedule">Program</a></li>
                <li><a class="nav-link scrollto" href="';
		echo LR\Filters::escapeHtmlAttr(LR\Filters::safeUrl($basePath)) /* line 43 */;
		echo '/#contact">Kontakt</a></li>
                <li><a href="';
		echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link('Gallery:default')) /* line 44 */;
		echo '" class="nav-link scrollto">Galerie</a></li>
';
		if ($user->isLoggedIn()) /* line 45 */ {
			echo '                    <a href="';
			echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link('Dashboard:default')) /* line 46 */;
			echo '" class="nav-link text-info disabled ">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person" viewBox="0 0 16 16">
                            <path d="M8 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6m2-3a2 2 0 1 1-4 0 2 2 0 0 1 4 0m4 8c0 1-1 1-1 1H3s-1 0-1-1 1-4 6-4 6 3 6 4m-1-.004c-.001-.246-.154-.986-.832-1.664C11.516 10.68 10.289 10 8 10s-3.516.68-4.168 1.332c-.678.678-.83 1.418-.832 1.664z"></path>
                        </svg> ';
			echo LR\Filters::escapeHtmlText($user->getIdentity()->username) /* line 49 */;
			echo '</a>
                    <li> <a href="';
			echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link('Dashboard:default')) /* line 50 */;
			echo '" class="nav-link text-warning">Administrace</a></li>
                <li> <a href="';
			echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link('Sign:out')) /* line 51 */;
			echo '" class="nav-link text-danger">Odhlásit se</a></li>

';
		} else /* line 53 */ {
			echo '                    <a href="';
			echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link('Sign:in')) /* line 54 */;
			echo '" class="nav-link text-primary ">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-key" viewBox="0 0 16 16">
                            <path d="M0 8a4 4 0 0 1 7.465-2H14a.5.5 0 0 1 .354.146l1.5 1.5a.5.5 0 0 1 0 .708l-1.5 1.5a.5.5 0 0 1-.708 0L13 9.207l-.646.647a.5.5 0 0 1-.708 0L11 9.207l-.646.647a.5.5 0 0 1-.708 0L9 9.207l-.646.647A.5.5 0 0 1 8 10h-.535A4 4 0 0 1 0 8m4-3a3 3 0 1 0 2.712 4.285A.5.5 0 0 1 7.163 9h.63l.853-.854a.5.5 0 0 1 .708 0l.646.647.646-.647a.5.5 0 0 1 .708 0l.646.647.646-.647a.5.5 0 0 1 .708 0l.646.647.793-.793-1-1h-6.63a.5.5 0 0 1-.451-.285A3 3 0 0 0 4 5"></path>
                            <path d="M4 8a1 1 0 1 1-2 0 1 1 0 0 1 2 0"></path>
                        </svg></a>
';
		}
		echo '            </ul>
            <i class="bi bi-list mobile-nav-toggle"></i>
        </nav><!-- .navbar -->

    </div>
</header><!-- End Header -->



<!-- Nette original code -->

';
		foreach ($flashes as $flash) /* line 73 */ {
			echo '                <div';
			echo ($ʟ_tmp = array_filter(['alert', 'alert-' . $flash->type])) ? ' class="' . LR\Filters::escapeHtmlAttr(implode(" ", array_unique($ʟ_tmp))) . '"' : "" /* line 73 */;
			echo '>';
			echo LR\Filters::escapeHtmlText($flash->message) /* line 73 */;
			echo '</div>
';

		}

		$this->renderBlock('content', [], 'html') /* line 75 */;
		echo '


<!-- ======= Footer ======= -->
<footer id="footer">
    <div class="container">
        <div class="copyright">
            &copy; Copyright <strong>RC Ponorka</strong>. All Rights Reserved
        </div>
        <div class="credits">
            <!--
            All the links in the footer should remain intact.
            You can delete the links only if you purchased the pro version.
            Licensing information: https://bootstrapmade.com/license/
            Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/buy/?theme=TheEvent
          -->
            Created by <a href="#">Mallcom</a>
            <a href="#" class="back-to-top d-flex align-items-center justify-content-center" style="display: none;">
                <i class="bi bi-arrow-up-short"></i>
            </a>
        </div>
    </div>
</footer><!-- End  Footer -->


';
		$this->renderBlock('scripts', get_defined_vars()) /* line 102 */;
		echo '

</body>
</html>
';
	}


	public function prepare(): array
	{
		extract($this->params);

		if (!$this->getReferringTemplate() || $this->getReferenceType() === 'extends') {
			foreach (array_intersect_key(['flash' => '73'], $this->params) as $ʟ_v => $ʟ_l) {
				trigger_error("Variable \$$ʟ_v overwritten in foreach on line $ʟ_l");
			}
		}
		$this->createTemplate('form-bootstrap5.latte', $this->params, "import")->render() /* line 1 */;
		return get_defined_vars();
	}


	/** {block head} on line 22 */
	public function blockHead(array $ʟ_args): void
	{
	}


	/** {block scripts} on line 102 */
	public function blockScripts(array $ʟ_args): void
	{
		extract($this->params);
		extract($ʟ_args);
		unset($ʟ_args);

		echo '
    <!-- Vendor JS Files -->
    <!-- <script src="assets/vendor/aos/aos.js"></script> -->
    <script src="';
		echo LR\Filters::escapeHtmlAttr(LR\Filters::safeUrl($basePath)) /* line 106 */;
		echo '/assets/vendor/bootstrap/js/bootstrap.bundle.min.js" defer></script>
    <!-- <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
    Zakomentován lightbox inicializace v main.js, odpojeno css i js = text webu se zobrazuje
        -->
    <!-- Template Main JS File -->
    <script src="';
		echo LR\Filters::escapeHtmlAttr(LR\Filters::safeUrl($basePath)) /* line 111 */;
		echo '/assets/js/main.js"></script>
    <script src="https://unpkg.com/nette-forms@3/src/assets/netteForms.js"></script>

';
	}
}
