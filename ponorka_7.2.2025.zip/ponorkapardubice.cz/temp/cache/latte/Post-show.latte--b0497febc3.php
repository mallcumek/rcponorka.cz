<?php

use Latte\Runtime as LR;

/** source: /data/web/virtuals/337245/virtual/www/domains/ponorkapardubice.cz/app/UI/Post/show.latte */
final class Template_b0497febc3 extends Latte\Runtime\Template
{
	public const Source = '/data/web/virtuals/337245/virtual/www/domains/ponorkapardubice.cz/app/UI/Post/show.latte';

	public const Blocks = [
		['head' => 'blockHead', 'content' => 'blockContent', 'title' => 'blockTitle'],
	];


	public function main(array $ʟ_args): void
	{
		extract($ʟ_args);
		unset($ʟ_args);

		if ($this->global->snippetDriver?->renderSnippets($this->blocks[self::LayerSnippet], $this->params)) {
			return;
		}

		$this->renderBlock('head', get_defined_vars()) /* line 1 */;
		echo "\n";
		$this->renderBlock('content', get_defined_vars()) /* line 8 */;
	}


	/** {block head} on line 1 */
	public function blockHead(array $ʟ_args): void
	{
		extract($this->params);
		extract($ʟ_args);
		unset($ʟ_args);

		echo '    <link href="';
		echo LR\Filters::escapeHtmlAttr(LR\Filters::safeUrl($basePath)) /* line 2 */;
		echo '/assets/css/ponorka.css" rel="stylesheet">
';
	}


	/** {block content} on line 8 */
	public function blockContent(array $ʟ_args): void
	{
		extract($this->params);
		extract($ʟ_args);
		unset($ʟ_args);

		echo '<main id="main" class="">
    <section id="gallery" class="">

        <div class="container py-5 ">
            <div class="section-header ">
                <p class="text-start pb-3"><a href="';
		echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link('Home:default#schedule')) /* line 14 */;
		echo '">← zpět na program</a>
';
		if ($user->isLoggedIn()) /* line 15 */ {
			echo '                        - <a href="';
			echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link('Edit:edit', [$post->id])) /* line 16 */;
			echo '" class="link-danger">upravit</a>
';
		}
		echo '                </p>
                <div class="row justify-content-center">
                    <div class="col-lg-6 bg-light text-dark">
                        <div class="date text-center pt-2 ">';
		echo LR\Filters::escapeHtmlText($formattedDate) /* line 21 */;
		echo '</div>
';
		$this->renderBlock('title', get_defined_vars()) /* line 22 */;
		echo '                        <div class="p-3 m-0 text-center ">
                            <p class="text-dark">Otevřeno: <strong>';
		echo LR\Filters::escapeHtmlText($post->opentime) /* line 24 */;
		echo '</strong><br> Začátek:
                                <strong>';
		echo LR\Filters::escapeHtmlText($post->starttime) /* line 25 */;
		echo '</strong><br>
';
		if ($post->presaleprice) /* line 26 */ {
			echo '                                    Předprodej: <strong>';
			echo LR\Filters::escapeHtmlText($post->presaleprice) /* line 27 */;
			echo '</strong> CZK<br>
';
		}
		echo '                                Na místě: <strong>';
		echo LR\Filters::escapeHtmlText($post->onsiteprice) /* line 29 */;
		echo '</strong> CZK<br>
';
		if ($post->presaleprice) /* line 30 */ {
			echo '                                    <a href="#">
                                        <button type="button" class="btn btn-sm btn-warning">Vstupenky</button>
                                    </a>
';
		}
		echo '
                            </p>
                        </div>
                        <div class="post pb-3 text-center">';
		echo LR\Filters::escapeHtmlText($post->content) /* line 38 */;
		echo '</div>
                        <div class="pb-3 text-center ">
                            <!-- Přepsání koncovky názvu obrázku z databáze, pro zobrazení malého resize náhledu-->
                            <img class="border border-dark w-100" loading="lazy"
                            src="';
		if ($post->image_path) /* line 42 */ {
			echo LR\Filters::escapeHtmlAttr(LR\Filters::safeUrl(($this->filters->replace)($post->image_path, '.webp', '-400w.webp'))) /* line 42 */;
		} else /* line 42 */ {
			echo 'https://placehold.co/300x300?text=You can change the image';
		}
		echo '"
                                 width="300"
                                 alt="';
		echo LR\Filters::escapeHtmlAttr($post->title) /* line 44 */;
		echo '"
                                 class="border border-dark">
                            </a>

                        </div>
                    </div>
                </div>
            </div>
            <div class="wrapper">
            </div>
        </div>

    </section>
</main>

';
	}


	/** n:block="title" on line 22 */
	public function blockTitle(array $ʟ_args): void
	{
		extract($this->params);
		extract($ʟ_args);
		unset($ʟ_args);

		echo '                        <h1 class="p-0 m-0  text-center text-uppercase fw-bold ">';
		echo LR\Filters::escapeHtmlText($post->title) /* line 22 */;
		echo '</h1>
';
	}
}
