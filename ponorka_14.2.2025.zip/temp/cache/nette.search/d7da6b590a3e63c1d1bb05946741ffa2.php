<?php
return array (
  0 => 
  array (
    'App\\Model\\PostFacade' => 
    array (
      0 => '/data/web/virtuals/337245/virtual/www/domains/ponorkapardubice.cz/app/Model/PostFacade.php',
      1 => 1739257983,
    ),
    'App\\Model\\UserFacade' => 
    array (
      0 => '/data/web/virtuals/337245/virtual/www/domains/ponorkapardubice.cz/app/Model/UserFacade.php',
      1 => 1737116880,
    ),
    'App\\Model\\DuplicateNameException' => 
    array (
      0 => '/data/web/virtuals/337245/virtual/www/domains/ponorkapardubice.cz/app/Model/UserFacade.php',
      1 => 1737116880,
    ),
    'App\\UI\\Accessory\\FormFactory' => 
    array (
      0 => '/data/web/virtuals/337245/virtual/www/domains/ponorkapardubice.cz/app/UI/Accessory/FormFactory.php',
      1 => 1737116882,
    ),
    'App\\UI\\Accessory\\RequireLoggedUser' => 
    array (
      0 => '/data/web/virtuals/337245/virtual/www/domains/ponorkapardubice.cz/app/UI/Accessory/RequireLoggedUser.php',
      1 => 1737116882,
    ),
    'App\\UI\\Edit\\EditPresenter' => 
    array (
      0 => '/data/web/virtuals/337245/virtual/www/domains/ponorkapardubice.cz/app/UI/Edit/EditPresenter.php',
      1 => 1739259776,
    ),
    'App\\UI\\Dashboard\\DashboardPresenter' => 
    array (
      0 => '/data/web/virtuals/337245/virtual/www/domains/ponorkapardubice.cz/app/UI/Dashboard/DashboardPresenter.php',
      1 => 1739355278,
    ),
    'App\\UI\\Gallery\\GalleryPresenter' => 
    array (
      0 => '/data/web/virtuals/337245/virtual/www/domains/ponorkapardubice.cz/app/UI/Gallery/GalleryPresenter.php',
      1 => 1739275324,
    ),
    'App\\UI\\Post\\PostPresenter' => 
    array (
      0 => '/data/web/virtuals/337245/virtual/www/domains/ponorkapardubice.cz/app/UI/Post/PostPresenter.php',
      1 => 1739218585,
    ),
    'App\\UI\\Sign\\SignPresenter' => 
    array (
      0 => '/data/web/virtuals/337245/virtual/www/domains/ponorkapardubice.cz/app/UI/Sign/SignPresenter.php',
      1 => 1739272629,
    ),
    'App\\UI\\Home\\HomePresenter' => 
    array (
      0 => '/data/web/virtuals/337245/virtual/www/domains/ponorkapardubice.cz/app/UI/Home/HomePresenter.php',
      1 => 1739218465,
    ),
    'App\\Bootstrap' => 
    array (
      0 => '/data/web/virtuals/337245/virtual/www/domains/ponorkapardubice.cz/app/Bootstrap.php',
      1 => 1737117981,
    ),
    'App\\Core\\RouterFactory' => 
    array (
      0 => '/data/web/virtuals/337245/virtual/www/domains/ponorkapardubice.cz/app/Core/RouterFactory.php',
      1 => 1739434348,
    ),
  ),
  1 => 
  array (
  ),
  2 => 
  array (
  ),
);
