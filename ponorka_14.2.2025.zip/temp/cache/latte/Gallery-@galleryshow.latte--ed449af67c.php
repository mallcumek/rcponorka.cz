<?php

use Latte\Runtime as LR;

/** source: /data/web/virtuals/337245/virtual/www/domains/ponorkapardubice.cz/app/UI/Gallery/@galleryshow.latte */
final class Template_ed449af67c extends Latte\Runtime\Template
{
	public const Source = '/data/web/virtuals/337245/virtual/www/domains/ponorkapardubice.cz/app/UI/Gallery/@galleryshow.latte';

	public const Blocks = [
		['head' => 'blockHead', 'scripts' => 'blockScripts'],
	];


	public function main(array $ʟ_args): void
	{
		extract($ʟ_args);
		unset($ʟ_args);

		if ($this->global->snippetDriver?->renderSnippets($this->blocks[self::LayerSnippet], $this->params)) {
			return;
		}

		echo '

<!DOCTYPE html>
<html lang="cs">
<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta name="robots" content="noindex, nofollow">
    <title>';
		if ($this->hasBlock('title')) /* line 9 */ {
			$this->renderBlock('title', [], function ($s, $type) {
				$ʟ_fi = new LR\FilterInfo($type);
				return LR\Filters::convertTo($ʟ_fi, 'html', $this->filters->filterContent('stripHtml', $ʟ_fi, $s));
			}) /* line 9 */;
			echo ' | ';
		}
		echo 'RC Ponorka Pardubice</title>
    <meta content="Rockový klub, bar, hospoda - Ponorka Pardubice." name="description">
    <meta content="rock, club, ponorka, pub" name="keywords">
    <!-- Favicons -->
    <link href="';
		echo LR\Filters::escapeHtmlAttr(LR\Filters::safeUrl($basePath)) /* line 13 */;
		echo '/assets/img/favicon.png" rel="icon">
    <link href="';
		echo LR\Filters::escapeHtmlAttr(LR\Filters::safeUrl($basePath)) /* line 14 */;
		echo '/assets/img/apple-touch-icon.png" rel="apple-touch-icon">
    <!-- Vendor CSS Files -->
    <link href="';
		echo LR\Filters::escapeHtmlAttr(LR\Filters::safeUrl($basePath)) /* line 16 */;
		echo '/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!--  pro PHPStorm nápovědu,  bez CDN prostě nenapovídá styly -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="';
		echo LR\Filters::escapeHtmlAttr(LR\Filters::safeUrl($basePath)) /* line 19 */;
		echo '/assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <!-- Template Main CSS File -->
    <link href="';
		echo LR\Filters::escapeHtmlAttr(LR\Filters::safeUrl($basePath)) /* line 21 */;
		echo '/assets/css/style.css" rel="stylesheet">
';
		$this->renderBlock('head', get_defined_vars()) /* line 22 */;
		echo '

</head>
<body>
<!-- ======= Header ======= -->



<!-- Nette original code -->



';
		$this->renderBlock('content', [], 'html') /* line 41 */;
		echo '

    <!-- ======= Footer ======= -->
<!-- End  Footer -->


';
		$this->renderBlock('scripts', get_defined_vars()) /* line 49 */;
		echo '

</body>
</html>
';
	}


	/** {block head} on line 22 */
	public function blockHead(array $ʟ_args): void
	{
	}


	/** {block scripts} on line 49 */
	public function blockScripts(array $ʟ_args): void
	{
		extract($this->params);
		extract($ʟ_args);
		unset($ʟ_args);

		echo '
    <!-- Vendor JS Files -->
    <!-- <script src="assets/vendor/aos/aos.js"></script> -->
    <script src="';
		echo LR\Filters::escapeHtmlAttr(LR\Filters::safeUrl($basePath)) /* line 53 */;
		echo '/assets/vendor/bootstrap/js/bootstrap.bundle.min.js" defer></script>
    <!-- <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
    Zakomentován lightbox inicializace v main.js, odpojeno css i js = text webu se zobrazuje
        -->
    <!-- Template Main JS File -->
    <script src="';
		echo LR\Filters::escapeHtmlAttr(LR\Filters::safeUrl($basePath)) /* line 58 */;
		echo '/assets/js/main.js"></script>
    <script src="https://unpkg.com/nette-forms@3/src/assets/netteForms.js"></script>

';
	}
}
