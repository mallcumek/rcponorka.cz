<?php

use Latte\Runtime as LR;

/** source: /data/web/virtuals/337245/virtual/www/domains/ponorkapardubice.cz/app/UI/Home/default.latte */
final class Template_e7c027ae18 extends Latte\Runtime\Template
{
	public const Source = '/data/web/virtuals/337245/virtual/www/domains/ponorkapardubice.cz/app/UI/Home/default.latte';

	public const Blocks = [
		['content' => 'blockContent'],
	];


	public function main(array $ʟ_args): void
	{
		extract($ʟ_args);
		unset($ʟ_args);

		if ($this->global->snippetDriver?->renderSnippets($this->blocks[self::LayerSnippet], $this->params)) {
			return;
		}

		$this->renderBlock('content', get_defined_vars()) /* line 1 */;
	}


	public function prepare(): array
	{
		extract($this->params);

		if (!$this->getReferringTemplate() || $this->getReferenceType() === 'extends') {
			foreach (array_intersect_key(['post' => '26'], $this->params) as $ʟ_v => $ʟ_l) {
				trigger_error("Variable \$$ʟ_v overwritten in foreach on line $ʟ_l");
			}
		}
		return get_defined_vars();
	}


	/** {block content} on line 1 */
	public function blockContent(array $ʟ_args): void
	{
		extract($this->params);
		extract($ʟ_args);
		unset($ʟ_args);

		echo '    <!-- ======= Hero Section ======= -->
    <section id="hero">
        <div class="hero-container">
            <h1 class="mb-4 pb-0">Rock Club<br><span>Ponorka</span></h1>
            <a href="#schedule" class="about-btn scrollto">Program</a>
            <a href="#contact" class="about-btn scrollto">Kontakt</a>
        </div>
    </section><!-- End Hero Section -->

    <main id="main">
        <!-- ======= Schedule Section ======= -->
        <section id="schedule" class="section-with-bg">
            <div class="container">
                <div class="section-header">
                    <h2>Program</h2>
                    <p>Kalendář akcí v rockovém klubu Ponorka, Pardubice.</p>
';
		if ($user->isLoggedIn()) /* line 18 */ {
			echo '                        <a href="';
			echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link('Edit:create')) /* line 19 */;
			echo '" class="link-danger fw-bold">Vytvořit novou událost</a>
';
		}
		echo '                </div>
                <div class="tab-content row justify-content-center">
                    <div class="col-lg-9 tab-pane fade show active">
';
		foreach ($posts as $post) /* line 26 */ {
			echo '                        <div class="row schedule-item">
                            <div class="col-md-2 d-flex align-items-center">
                                <!-- Použití formátovaného data z pole -->
                                <time>';
			echo LR\Filters::escapeHtmlText($formattedDates[$post->id]) /* line 29 */;
			echo '</time>
                            </div>
                            <div class="col-md-10 d-flex">
                                <div class="speaker">
                                    <a href="';
			echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link('Post:show', [$post->id])) /* line 33 */;
			echo '#schedule">
                                        <!-- Přepsání koncovky názvu obrázku z databáze, pro zobrazení malého resize náhledu -->
                                        <img loading="lazy"
                                             src="';
			if ($post->image_path) /* line 36 */ {
				echo LR\Filters::escapeHtmlAttr(LR\Filters::safeUrl(($this->filters->replace)($post->image_path, '.webp', '-400w.webp'))) /* line 36 */;
			} else /* line 36 */ {
				echo 'https://placehold.co/300x300?text=You can change the image';
			}
			echo '"
                                             alt="';
			echo LR\Filters::escapeHtmlAttr($post->title) /* line 37 */;
			echo '"
                                             class="border border-dark">
                                    </a>
                                </div>
                                <div class="text ">
                                    <h3><a href="';
			echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link('Post:show', [$post->id])) /* line 42 */;
			echo '#schedule">';
			echo LR\Filters::escapeHtmlText($post->title) /* line 42 */;
			echo '</a></h3>
                                    <p>Otevřeno: <strong>';
			echo LR\Filters::escapeHtmlText($post->opentime) /* line 43 */;
			echo '</strong> <br> Začátek:
                                        <strong>';
			echo LR\Filters::escapeHtmlText($post->starttime) /* line 44 */;
			echo '</strong>.</p>
                                    <p>Na místě: <strong>';
			echo LR\Filters::escapeHtmlText($post->onsiteprice) /* line 45 */;
			echo ' Kč</strong>
                                    </p>
';
			if ($post->presaleprice) /* line 47 */ {
				echo '                                        <p>Předprodej: <strong>';
				echo LR\Filters::escapeHtmlText($post->presaleprice) /* line 48 */;
				echo ' Kč</strong> <br>
                                            <button type="button" class="btn btn-sm btn-warning">Vstupenky</button>
                                        </p>
';
			}
			echo '                                </div>

                            </div>
                            <p class="text-dark">';
			echo LR\Filters::escapeHtmlText(($this->filters->truncate)($post->content, 256)) /* line 55 */;
			echo '</p>
                        </div>
';

		}

		echo '
                    </div> <!-- End Schdule Day 1 col -->

                </div> <!-- End tab-content row-->

            </div>

        </section><!-- End Schedule Section -->


        <!-- ======= Contact Section ======= -->
        <section id="contact" class="section-bg">

            <div class="container">

                <div class="section-header">
                    <h2>Kontakt</h2>
                    <p>Máte-li dotaz, pište, volejte, těšíme se na vás.</p>
                </div>

                <div class="row contact-info">


                    <div class="col-md-4">
                        <div class="contact-address">
                            <i class="bi bi-geo-alt"></i>
                            <h3>Club Ponorka</h3>
                            <address>Jiráskova 29, 530 02 Pardubice I</address>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="contact-phone">
                            <i class="bi bi-phone"></i>
                            <h3>Telefon</h3>
                            <p><a href="tel:+155895548855">+402 608 606 606</a></p>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="contact-email">
                            <i class="bi bi-envelope"></i>
                            <h3>Email</h3>
                            <p><a href="mailto:info@example.com">info@rcponorka.cz</a></p>
                        </div>
                    </div>

                </div>
                <h3>Napište nám zprávu</h3>
                <div class="form">
                    <form action="forms/contact.php" method="post" role="form" class="php-email-form">
                        <div class="row">
                            <div class="form-group col-md-6">
                                <input type="text" name="name" class="form-control" id="name" placeholder="Jméno"
                                       required>
                            </div>
                            <div class="form-group col-md-6 mt-3 mt-md-0">
                                <input type="email" class="form-control" name="email" id="email" placeholder="Email"
                                       required>
                            </div>
                        </div>
                        <div class="form-group mt-3">
                            <input type="text" class="form-control" name="subject" id="subject" placeholder="Předmět"
                                   required>
                        </div>
                        <div class="form-group mt-3">
                            <textarea class="form-control" name="message" rows="5" placeholder="Zpráva"
                                      required></textarea>
                        </div>
                        <div class="my-3">
                            <div class="loading">Loading</div>
                            <div class="error-message"></div>
                            <div class="sent-message">Your message has been sent. Thank you!</div>
                        </div>
                        <div class="text-center">
                            <button type="submit">Odeslat zprávu</button>
                        </div>
                    </form>
                </div>

            </div>
        </section><!-- End Contact Section -->

    </main><!-- End #main -->


';
	}
}
