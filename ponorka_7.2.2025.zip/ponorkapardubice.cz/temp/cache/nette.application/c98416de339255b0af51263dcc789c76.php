<?php
return array (
  0 => 
  array (
    'App\\UI\\Edit\\EditPresenter' => 
    array (
      0 => '/data/web/virtuals/337245/virtual/www/domains/ponorkapardubice.cz/app/UI/Edit/EditPresenter.php',
      1 => 1738599385,
    ),
    'App\\UI\\Dashboard\\DashboardPresenter' => 
    array (
      0 => '/data/web/virtuals/337245/virtual/www/domains/ponorkapardubice.cz/app/UI/Dashboard/DashboardPresenter.php',
      1 => 1738675392,
    ),
    'App\\UI\\Gallery\\GalleryPresenter' => 
    array (
      0 => '/data/web/virtuals/337245/virtual/www/domains/ponorkapardubice.cz/app/UI/Gallery/GalleryPresenter.php',
      1 => 1738674873,
    ),
    'App\\UI\\Post\\PostPresenter' => 
    array (
      0 => '/data/web/virtuals/337245/virtual/www/domains/ponorkapardubice.cz/app/UI/Post/PostPresenter.php',
      1 => 1738573900,
    ),
    'App\\UI\\Sign\\SignPresenter' => 
    array (
      0 => '/data/web/virtuals/337245/virtual/www/domains/ponorkapardubice.cz/app/UI/Sign/SignPresenter.php',
      1 => 1737116888,
    ),
    'App\\UI\\Home\\HomePresenter' => 
    array (
      0 => '/data/web/virtuals/337245/virtual/www/domains/ponorkapardubice.cz/app/UI/Home/HomePresenter.php',
      1 => 1738588628,
    ),
  ),
  1 => 
  array (
  ),
  2 => 
  array (
  ),
);
