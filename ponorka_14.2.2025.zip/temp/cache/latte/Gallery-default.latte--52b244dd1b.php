<?php

use Latte\Runtime as LR;

/** source: /data/web/virtuals/337245/virtual/www/domains/ponorkapardubice.cz/app/UI/Gallery/default.latte */
final class Template_52b244dd1b extends Latte\Runtime\Template
{
	public const Source = '/data/web/virtuals/337245/virtual/www/domains/ponorkapardubice.cz/app/UI/Gallery/default.latte';

	public const Blocks = [
		['head' => 'blockHead', 'content' => 'blockContent'],
	];


	public function main(array $ʟ_args): void
	{
		extract($ʟ_args);
		unset($ʟ_args);

		if ($this->global->snippetDriver?->renderSnippets($this->blocks[self::LayerSnippet], $this->params)) {
			return;
		}

		$this->renderBlock('head', get_defined_vars()) /* line 1 */;
		$this->renderBlock('content', get_defined_vars()) /* line 4 */;
	}


	public function prepare(): array
	{
		extract($this->params);

		if (!$this->getReferringTemplate() || $this->getReferenceType() === 'extends') {
			foreach (array_intersect_key(['post' => '18'], $this->params) as $ʟ_v => $ʟ_l) {
				trigger_error("Variable \$$ʟ_v overwritten in foreach on line $ʟ_l");
			}
		}
		return get_defined_vars();
	}


	/** {block head} on line 1 */
	public function blockHead(array $ʟ_args): void
	{
		extract($this->params);
		extract($ʟ_args);
		unset($ʟ_args);

		echo '    <link href="';
		echo LR\Filters::escapeHtmlAttr(LR\Filters::safeUrl($basePath)) /* line 2 */;
		echo '/assets/css/grid.css" rel="stylesheet">
';
	}


	/** {block content} on line 4 */
	public function blockContent(array $ʟ_args): void
	{
		extract($this->params);
		extract($ʟ_args);
		unset($ʟ_args);

		echo '    <main id="main" class="">
        <section id="gallery" class="">
            <div class="container-fluid py-5">
                <div class="section-header">
                    <h2 class="text-white">Galerie</h2>
                    <p class="text-white pb-2">Fotky z proběhlých akcí v Ponorce.</p>

                    <div class="wrapper ms-auto me-auto">
';
		if ($user->isLoggedIn()) /* line 13 */ {
			echo '                            <h3><a href="';
			echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link('Dashboard:create')) /* line 14 */;
			echo '" class="link-danger">Přidat fotku do galerie</a></h3>
';
		}
		echo '                        <div class="masonry">
';
		foreach ($posts as $post) /* line 18 */ {
			echo '                            <div class="masonry-brick">
                                <div class="masonry-content bg-black">
                                    <a href="';
			echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link('Gallery:show', [$post->id])) /* line 20 */;
			echo '">
                                        <img class="border border-dark w-100" loading="lazy"
                                             src="';
			if ($post->image_path) /* line 22 */ {
				echo LR\Filters::escapeHtmlAttr(LR\Filters::safeUrl(($this->filters->replace)($post->image_path, '.webp', '-1920wmax.webp'))) /* line 22 */;
			} else /* line 22 */ {
				echo 'https://placehold.co/300x300?text=You can change the image';
			}
			echo '"
                                             width="200" height="200"
                                             alt="';
			echo LR\Filters::escapeHtmlAttr($post->title) /* line 24 */;
			echo '">
                                    </a>
                                    <p class="masonry-description text-center"><strong>';
			echo LR\Filters::escapeHtmlText($post->title) /* line 26 */;
			echo '</strong></p>

                                </div>
                            </div>
';

		}

		echo '                        </div>
                    </div>
                </div>
            </div>


            <script src="';
		echo LR\Filters::escapeHtmlAttr(LR\Filters::safeUrl($basePath)) /* line 36 */;
		echo '/assets/js/imagesloaded.pkgd.min.js"></script>
            <script>
                /**
                 * Set appropriate spanning to any masonry item
                 *
                 * Get different properties we already set for the masonry, calculate
                 * height or spanning for any cell of the masonry grid based on its
                 * content-wrapper\'s height, the (row) gap of the grid, and the size
                 * of the implicit row tracks.
                 *
                 * @param item Object A brick/tile/cell inside the masonry
                 */
                function resizeMasonryItem(item) {
                    /* Get the grid object, its row-gap, and the size of its implicit rows */
                    var grid = document.getElementsByClassName(\'masonry\')[0],
                        rowGap = parseInt(window.getComputedStyle(grid).getPropertyValue(\'grid-row-gap\')),
                        rowHeight = parseInt(window.getComputedStyle(grid).getPropertyValue(\'grid-auto-rows\'));

                    /*
                     * Spanning for any brick = S
                     * Grid\'s row-gap = G
                     * Size of grid\'s implicitly create row-track = R
                     * Height of item content = H
                     * Net height of the item = H1 = H + G
                     * Net height of the implicit row-track = T = G + R
                     * S = H1 / T
                     */
                    var rowSpan = Math.ceil((item.querySelector(\'.masonry-content\').getBoundingClientRect().height + rowGap) / (rowHeight + rowGap));

                    /* Set the spanning as calculated above (S) */
                    item.style.gridRowEnd = \'span \' + rowSpan;
                }

                /**
                 * Apply spanning to all the masonry items
                 *
                 * Loop through all the items and apply the spanning to them using
                 * `resizeMasonryItem()` function.
                 *
                 * @uses resizeMasonryItem
                 */
                function resizeAllMasonryItems() {
                    // Get all item class objects in one list
                    var allItems = document.getElementsByClassName(\'masonry-brick\');

                    /*
                     * Loop through the above list and execute the spanning function to
                     * each list-item (i.e. each masonry item)
                     */
                    // Projdi výše uvedený seznam a proveď funkci překrytí na každé položce
                    // * Změna podmínky v cyklu for z > na < pomohla opravit nacitani layoutu po nacteni obrazku a i po otoceni displeje.
                    for (var i = 0; i < allItems.length; i++) {
                        resizeMasonryItem(allItems[i]);
                    }
                }

                /**
                 * Resize the items when all the images inside the masonry grid
                 * finish loading. This will ensure that all the content inside our
                 * masonry items is visible.
                 *
                 * @uses ImagesLoaded
                 * @uses resizeMasonryItem
                 */
                function waitForImages() {
                    var allItems = document.getElementsByClassName(\'masonry-brick\');
                    for (var i = 0; i < allItems.length; i++) {
                        imagesLoaded(allItems[i], function (instance) {
                            var item = instance.elements[0];
                            resizeMasonryItem(item);
                        });
                    }
                }


                // Změň velikost všech položek mřížky při načítání, změně velikosti a při změně orientace
                var masonryEvents = [\'load\', \'resize\', \'orientationchange\'];
                masonryEvents.forEach(function (event) {
                    window.addEventListener(event, resizeAllMasonryItems);
                });

                // Přidání detekce zoomu a změny velikosti
                window.addEventListener(\'resize\', function () {
                    resizeAllMasonryItems();
                });


                // Proveď změnu velikosti ještě jednou, když všechny obrázky dokončí načítání
                waitForImages();
            </script>


        </section>


    </main><!-- End #main -->


';
	}
}
