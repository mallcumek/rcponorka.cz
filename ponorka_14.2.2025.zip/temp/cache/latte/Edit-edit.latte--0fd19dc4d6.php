<?php

use Latte\Runtime as LR;

/** source: /data/web/virtuals/337245/virtual/www/domains/ponorkapardubice.cz/app/UI/Edit/edit.latte */
final class Template_0fd19dc4d6 extends Latte\Runtime\Template
{
	public const Source = '/data/web/virtuals/337245/virtual/www/domains/ponorkapardubice.cz/app/UI/Edit/edit.latte';

	public const Blocks = [
		['head' => 'blockHead', 'content' => 'blockContent'],
	];


	public function main(array $ʟ_args): void
	{
		extract($ʟ_args);
		unset($ʟ_args);

		if ($this->global->snippetDriver?->renderSnippets($this->blocks[self::LayerSnippet], $this->params)) {
			return;
		}

		$this->renderBlock('head', get_defined_vars()) /* line 1 */;
		echo "\n";
		$this->renderBlock('content', get_defined_vars()) /* line 5 */;
	}


	/** {block head} on line 1 */
	public function blockHead(array $ʟ_args): void
	{
		extract($this->params);
		extract($ʟ_args);
		unset($ʟ_args);

		echo '    <link href="';
		echo LR\Filters::escapeHtmlAttr(LR\Filters::safeUrl($basePath)) /* line 2 */;
		echo '/assets/css/ponorka.css" rel="stylesheet">
';
	}


	/** {block content} on line 5 */
	public function blockContent(array $ʟ_args): void
	{
		extract($this->params);
		extract($ʟ_args);
		unset($ʟ_args);

		echo '<main id="main" class="">
    <section id="gallery" class="">

        <div class="container py-5 ">
            <div class="section-header ">
                <p class="text-start pb-3"><a href="';
		echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link('Home:default#schedule')) /* line 11 */;
		echo '">← zpět na program</a></p>
                <div class="row justify-content-center">
                    <div class="col-lg-6 bg-light text-dark">


                        <h1 class="text-center pt-3">Upravit událost</h1>

';
		$ʟ_tmp = $this->global->uiControl->getComponent('postForm');
		if ($ʟ_tmp instanceof Nette\Application\UI\Renderable) $ʟ_tmp->redrawControl(null, false);
		$ʟ_tmp->render() /* line 18 */;

		echo '
                        <div class="d-flex justify-content-center p-3 ">

                            <img id="image-preview"
                                 class="border border-dark img-fluid"

                                 src="';
		if ($post->image_path) /* line 25 */ {
			echo LR\Filters::escapeHtmlAttr(LR\Filters::safeUrl(($this->filters->replace)($post->image_path, '.webp', '-400w.webp'))) /* line 25 */;
		} else /* line 25 */ {
			echo '/https://placehold.co/300x300?text=You can change the image.';
		}
		echo '"
                                 height="300" alt="Image preview"/>
                        </div>

                        <br>
                        <a href="';
		echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link('deletePost!', [$post->id])) /* line 30 */;
		echo '"
                                onclick="return confirm(\'Opravdu chcete smazat tento příspěvek?\')"
                                class="btn btn-danger m-2">
                            Smazat příspěvek
                        </a>

                    </div>
                </div>
            </div>
        </div>
    </section>
</main>

<script type="text/javascript">

    // Preview an image before it is uploaded
    document.getElementById(\'frm-postForm-image\').onchange = evt => {
        const [file] = evt.target.files;
        if (file) {
            document.getElementById(\'image-preview\').src = URL.createObjectURL(file);
        }
    };
</script>';
	}
}
