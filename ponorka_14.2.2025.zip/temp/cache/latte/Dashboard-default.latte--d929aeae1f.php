<?php

use Latte\Runtime as LR;

/** source: /data/web/virtuals/337245/virtual/www/domains/ponorkapardubice.cz/app/UI/Dashboard/default.latte */
final class Template_d929aeae1f extends Latte\Runtime\Template
{
	public const Source = '/data/web/virtuals/337245/virtual/www/domains/ponorkapardubice.cz/app/UI/Dashboard/default.latte';

	public const Blocks = [
		['head' => 'blockHead', 'content' => 'blockContent'],
	];


	public function main(array $ʟ_args): void
	{
		extract($ʟ_args);
		unset($ʟ_args);

		if ($this->global->snippetDriver?->renderSnippets($this->blocks[self::LayerSnippet], $this->params)) {
			return;
		}

		$this->renderBlock('head', get_defined_vars()) /* line 1 */;
		echo "\n";
		$this->renderBlock('content', get_defined_vars()) /* line 5 */;
	}


	/** {block head} on line 1 */
	public function blockHead(array $ʟ_args): void
	{
		extract($this->params);
		extract($ʟ_args);
		unset($ʟ_args);

		echo '    <link href="';
		echo LR\Filters::escapeHtmlAttr(LR\Filters::safeUrl($basePath)) /* line 2 */;
		echo '/assets/css/ponorka.css" rel="stylesheet">
';
	}


	/** {block content} on line 5 */
	public function blockContent(array $ʟ_args): void
	{
		extract($this->params);
		extract($ʟ_args);
		unset($ʟ_args);

		echo '<main id="main" class="">
    <section id="gallery" class="">

        <div class="container py-5 ">
            <div class="section-header ">

                <div class="row justify-content-center">
                    <div class="col-lg-6 bg-light text-dark text-start pt-3 pb-3">


                    <h1 class="text-start pb-0 mb-0">Administrace</h1>
                    <p class="text-start link-danger fw-bold ">Pozor! Jste přihlášení a můžete měnit obsah webu.</p>
                    <h2 class="text-start pt-5">Nastavení programu</h2>
                    <p class="text-dark text-start">
                        Události můžete přidávat a upravovat na hlavní stránce v kategorii
                        <a href="';
		echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link('Home:default#schedule')) /* line 21 */;
		echo '" class="link-primary">program</a>.
                    <h3 class="pb-0 mb-0"><a href="';
		echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link('Edit:create')) /* line 22 */;
		echo '" class="link-primary">Vytvořit novou událost</a>
                    </h3>
                    <h3 class="pb-0 mb-0"><a href="';
		echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link('Home:default#schedule')) /* line 24 */;
		echo '" class="link-primary">Upravit stávající
                            události </a></h3> </p>

                    <h2 class="text-start pt-5">Nastavení galerie</h2>
                    <p class="text-dark text-start">
                        Fotky do galerie můžete přidávat i měnit přímo na stránce
                        <a href="';
		echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link('Gallery:default')) /* line 30 */;
		echo '" class="link-primary">galerie</a>.
                    <h3 class="pb-0 mb-0"><a href="';
		echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link('Dashboard:create')) /* line 31 */;
		echo '" class="link-primary">Přidat novou fotku do
                            galerie</a></h3>
                    <h3 class="pb-0 mb-0"><a href="';
		echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link('Gallery:default')) /* line 33 */;
		echo '" class="link-primary">Upravit stávající fotky v
                            galerii</a></h3>

                    </p>


                </div>
                </div>

            </div>
        </div>
        </div>

    </section>
</main>

<script type="text/javascript">

    // Preview an image before it is uploaded
    document.getElementById(\'frm-postForm-image\').onchange = evt => {
        const [file] = evt.target.files;
        if (file) {
            document.getElementById(\'image-preview\').src = URL.createObjectURL(file);
        }
    };
</script>

';
	}
}
